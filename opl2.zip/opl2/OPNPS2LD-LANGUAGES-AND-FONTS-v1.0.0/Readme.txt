===================================================================================================

This is Open PS2 Loader v1.0.0 language pack. 28 languages are available. 

These language files are to be used with OPL v1.0.0 stable releases ONLY (rev851, commit e505136).
 
You can download v1.0.0 stable release from here: 
https://github.com/ps2homebrew/Open-PS2-Loader/releases/tag/v1.0.0

===================================================================================================

LANGUAGE - AUTHOR (STATUS)

- Arabic - translated by LightWave (missing untranslated lines)
  "Lines 10, 22, 44, 109, 117, 118, 134, 140, 146, 185, 186, 200"
  "Lines from 211 to 283"
- Bulgarian - translated by wisi (100% translated) 
- Croatian - translated by Blacky5678 (missing untranslated lines):
  "Lines 278, 279, 280, 281, 282, 283".
- Czech - translated by jimmysmith (missing untranslated lines):
  "Lines 10, 44, 109, 146, 200"
  "Lines from 213 to 283"
- Danish - translated by BongKris (missing untranslated lines):
  "Lines 10, 44, 109, 146, 200"
  "Lines 249 to 283"
- Dutch - translated by PS2Gaming (missing untranslated lines):
  "Lines 10, 44, 109, 146, 200"
  "Lines from 233 to 283"
- Filipino - translated by Ceed Lorenzo (missing untranslated lines): 
  "Lines 7, 8, 10, 13, 14, 21, 23, 24, 25, 26, 27, 31, 32, 33, 34, 38, 39, 40, 41, 42, 43, 44, 60, 81, 82, 83, 84, 
  85, 86, 87, 88, 89, 92, 94, 99, 103, 104, 106, 107, 109, 111, 112, 114, 115, 116, 117, 118, 121, 134, 137, 138, 
  140, 143, 146, 148, 170"
  "Lines from 178 to 283"
- French - translated by ShaolinAssassin completed by Algol (100% translated)
- German - translated by ps2guy completed by LopoTRI & TnA (100% translated)
- Greek - translated by RivalK93 (100% translated)
- Hungarian - translated by co5oos (100% translated)
- Indonesian - translated by verislasher (100% translated)
- Italian - translated by jauffreBlades completed by Peppe90 (100% translated)
- Japanese - translated by yamamotonew (missing untranslated lines):
  "Lines 10, 44, 109, 117, 118, 146, 185, 186, 200, 235, 236, 237"  
  "Lines from 267 to 283"
- Korean - translated by ddinghoya (missing untranslated line):
  "Line 146"  
- Laotian - translated by blackbutterfly (missing untranslated lines):
  "Lines 10, 44, 74, 86, 87, 88, 89, 90, 109, 116, 117, 118, 134, 139, 146, 152, 153, 154, 155, 185, 186, 200, 211"
  "Lines from 213 to 283"
- Persian - translated by saeid0035 (100% translated)  
- Polish - translated by dragolice completed by Jolek & KaiQ (100% translated) 
- Portuguese-BR - translated by gledson999 (100% translated)
- Portuguese - translated by danielb (100% translated)
- Romanian - translated by MRAdyy (missing untranslated lines):
  "Lines 10, 44, 109, 146, 200"
  "Lines from 211 to 283"
- Russian - translated by druchapucha & frodosumkin (missing untranslated line):
  "Line 109"
- Simplified Chinese - Translated by eyu2007 (missing untranslated lines):
  "Lines 146, 278, 279, 280, 281, 282, 283" 
- Spanish - translated by El_Patas (100% translated)
- Swedish - translated by Flaya (100% translated)
- Traditional Chinese - translated by kane159 (missing untranslated lines):
  "Lines 146, 212, 278, 279, 280, 281, 282, 283"
- Turkish - translated by dante (100% translated)
- Vietnamese - translated by zidane89 (missing untranslated lines):
  "Lines 7, 10, 14, 44, 45, 109, 134, 139, 140, 146, 151, 152, 155, 171, 185, 186, 200, 212"
  "Lines from 267 to 283"  

Credits to their authors.

Let's not forget all former OPL translators, as their translations are often used as a 
base for updates, so they should also be credited. 

===================================================================================================

HOW TO USE?

1. Copy/paste the language file "lang_nameofyourlanguage.lng", and the font file "font_nameofyourlanguage.ttf",
   (using uLE) into the memory card, or in your device following this paths:
   
   * Memory card (MC)
     mc0:/OPL
     mc1:/OPL 

   * Hard disk (HDD) (If you load your lang/font from HDD, start mode must be set on "AUTO").
     hdd0:/+OPL/LNG 

   * Ehernet (SMB) (For SMB, lang/font needs to be in LNG in shared folder).
     Shared folder/OPL/LNG  

   * USB 
     mass:/LNG   

   Fonts are needed for some languages because they uses some special glyphs, although there are languages 
   that do not need a special font.
   
2. In OPL, go to the main settings screen, then enter "Display settings" and set 
   your language from there.
   Arabic and persian languages must be used with the OPL compiled with "RTL" (Right to left), so that 
   the texts can be read correctly.

3. Do not forget to save your settings. 

4. Enjoy OPL in your language. ;)

===================================================================================================

HOW TO USE A CUSTOM FONT WITH OPL BUILT-IN ENGLISH?

1. Grab the file named "lan_EN-CustomFont.lng" (in "English for custom font users" 
   folder) and copy/paste it (using uLE), into the memory card or your device
   in the paths described in the previous section "How to use?".

2. Rename your custom font "font_EN-CustomFont.ttf", and place it into the memory card 
   or your device in the paths described in the previous section "How to use?".

3. In OPL, go to the main settings screen, then enter "Display settings" and set 
   "EN-CustomFont" from there.

4. Do not forget to save your Settings. 

5. Enjoy OPL in english with a custom font. ;)

===================================================================================================

MY LANGUAGE IS NOT LISTED! 

Use the template below. Feel free to submit it https://www.psx-place.com/threads/open-ps2-loader-beta-revisions-releases-language-pack.20547/

===================================================================================================

TEMPLATE for Open PS2 Loader - 0.9.3 

###################################################################################################
# This file is a template for translators. This file's encoding must be UTF8.                     #
#                                                                                                 #
# Translate every line, keeping the same order. Don't add empty lines.                            #
# Any missing lines will be substituted with the English defaults from lang.c.                    #
#                                                                                                 #
# Important: if your language require some custom glyphs, you should provide a corresponding      #
# TTF/OTF font file too. By default, OPL only comes with the "basic Latin" font built-in.         #
#                                                                                                 #
# Once the translation is complete, you can submit it to the development team.                    #
#                                                                                                 #
# To use your custom language with OPL, simply copy your file into your mc?:/OPL or LNG folder.   #
# (File must start with the "lang_" prefix and have the ".lng" extension)                         #
#                                                                                                 #
# Finally, don't put too many comments in your file, it will waste space and increases loading    #
# time. One single comment line on top (e.g. "name <yourmail@address.com>") should be enough.     #
#                                                                                                 #
# Thanks for your work.                                                                           #
#                                                                                                 #
###################################################################################################
#
# Put here the English name of your language (will be displayed in the OPL Settings menu), in standard latin characters.
English template
Open PS2 Loader %s
Save Changes
Back
Network Settings
Advanced Options
<no values>
Settings saved to %s
Error writing settings!
Exit
Settings
Menu
USB Games
HDD Games
ETH Games
Apps
Theme
Language
The system will be powered off.
Exit to Browser?
Cancel updating?
%d: HardDisk Drive not detected.
%d: HardDisk Drive not formatted.
%d: Network startup error.
%d: No network adaptor detected.
%d: Cannot connect to SMB server.
%d: Cannot log into SMB server.
%d: Cannot open SMB share.
%d: Cannot list SMB shares.
%d: Cannot list games.
%d: DHCP server unavailable.
%d: No network connection.
On
Off
OK
Select
Cancel
Circle
Cross
Games List
Game Settings
Remove Settings
Removed all keys for the game.
Scrolling
Slow
Medium
Fast
Default Menu
Load From Disc
Please wait.
Error while loading the Game ID.
Automatic Sorting
Error loading the language file.
Disable Debug Colors
No controller detected, waiting...
Enable Cover Art
Widescreen
Power Off
Loading config...
Saving config...
Start Device
Refresh
USB Device Start Mode
HDD Device Start Mode
ETH Device Start Mode
Applications Start Mode
Auto
Manual
Start HDL Server
HDL Server starting...
HDL Server running...
Failed to start HDL Server.
HDL Server unloading...
IGR Path
Background Color
Text Color
- PS2 -
- SMB Server -
IP Address Type
Static
DHCP
IP Address
Address
Mask
Gateway
DNS Server
Port
Share
User
Password
<not set>
Address Type
IP
NetBIOS
Accept
Item will be permanently deleted, continue?
Rename
Delete
Run
Display Settings
Enable Write Operations
Check USB Game Fragmentation
Remember Last Played Game
Select Button
Error, the game is fragmented.
Error, could not run the item.
Test Changes
Leave empty for GUEST auth.
Accurate Reads
Synchronous Mode
Unhook Syscalls
Skip Videos
Emulate DVD-DL
Disable IGR
Unused
Unused
Changing the size will reformat the VMC.
Create
Start
Modify
Abort
Reset
Use Generic
Configure VMC
Name
Size
Status
Progress
VMC file exists.
Invalid VMC file, size is incorrect.
VMC file needs to be created.
Error accessing VMC %s. Continue with the Memory Card in slot %d?
Automatic Refresh
About
Coders
Quality Assurance
USB Prefix Path
Boots custom ELF after an IGR.
Value in minute(s), 0 to disable spin down.
Automatic HDD Spin Down
Video Mode
Dialog Color
Selected Color
Reset Colors
Info
Custom ELF
Color Selection
Reconnect
Leave empty to list shares.
ETH Prefix Path
Backspace
Space
Enter
Mode
VMC Slot 1
VMC Slot 2
Game ID
DMA Mode
V-Sync
Mode 1
Mode 2
Mode 3
Mode 4
Mode 5
Mode 6
Mode 7
Mode 8
Configure GSM
Ethernet Link Mode
100Mbit Full-duplex
100Mbit Half-duplex
10Mbit Full-duplex
10Mbit Half-duplex
GSM Settings
Enable GSM
Toggles GSM on/off.
VMODE
Forced custom display mode.
H-POS
Horizontal adjustment.
V-POS
Vertical adjustment.
Overscan
Overscan adjustment.
FMV Skip
Skips full motion videos.
Cheat Settings
Enable PS2RD Cheat Engine
Lets PS2RD Cheat Engine patch your game.
PS2RD Cheat Engine Mode
Auto select or select game cheats.
Auto Select Cheats
Select Game Cheats
Error: failed to load cheat file.
No cheats found.
Download Defaults
Network Update
Overwrite Existing Records
Update failed.
Failed to connect to update server.
Update completed.
Update cancelled.
Download settings from the network?
Customized Settings
Downloaded Defaults
Auto start in %i s...
Auto Start
Value in second(s), 0 to disable auto start.
PS2 Logo
Displayed for a valid disc logo matching the console's region.
Configure PADEMU
Pad Emulator Settings
Enable Pad Emulator
Turns on/off Pad Emulator for selected game.
Pad Emulator Mode
Select Pad Emulator mode.
DualShock3/4 USB
DualShock3/4 BT
Settings For Port:
Select Pad Emulator port for settings.
Enable Emulation
Turns on/off Pad Emulator for selected port.
Enable Vibration
Turns on/off vibration for Pad Emulator selected port.
USB Bluetooth Adapter MAC Address:
DS Controller Paired To MAC Address:
Pair
Pair DS Controller
Pair DS controller with Bluetooth adapter MAC address.
Not Connected
Bluetooth Adapter Information
Shows more information and supported features.
HCI Version:
LMP Version:
Manufacturer ID:
Supported Features:
Yes
No
Bluetooth adapter should be fully compatible with DS3/DS4 controllers.
Bluetooth adapter may not work correctly with DS3/DS4 controllers.
Enable Multitap Emulation
Turns on/off Multitap emulation for selected game.
Multitap Emulator On Port:
Select port for Multitap emulation.
Disable Fake DS3 Workaround
Some fake DS3s need workaround, this option will disable it.
Emulate FIELD Flipping
Fix for games that glitch under progressive video modes.
Parental Lock Settings
Parental Lock Password
Leave blank to disable the parental lock.
Enter Parental Lock Password
Parental lock password incorrect.
Parental lock disabled.
Build Options:
Error - this password cannot be used.
VMC %s file is fragmented. Continue with Memory Card in slot %d?
Audio Settings
Enable Sound Effects
Enable Boot Sound
Sound Effects Volume
Boot Sound Volume
Confirm video mode change?
Cache Game List (HDD)
Enable Notifications
%s loaded from %s
Game Menu
Game settings saved.
%s settings removed.
Overwrites existing game compatibility settings when enabled.
Settings Mode
Global
Per Game
All
Select settings to remove.
Support Forums:
Title
Genre
Release
Developer
Description
# [end of the template]


